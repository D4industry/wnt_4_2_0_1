# Please refer to latest cloud documetation in https://developer.wirepas.com
# Example on how to run without an inventory file:
###   ansible-playbook -i myinstance.mydnszone.com, cli_setup_host.yml

###   ansible-playbook -i myinstance.mydnszone.com, cli_update_host.yml (see doc for updating WNT3.x version.)
This version updates wnt **ONLY**  from 3.0.x or 4.x to 4.2 and only applies to the WNT installation done with latest
self-hosting package (which bases on Ubuntu20.04 or 22.04) Updating 3.0 to 4.0 in ubuntu18.04 will most likely result in
package conflicts which you will have to sort out. We recommend creating a backup and restoring that on a fresh
installation on Ubuntu20.04/22.04.

Issues:

Running update multiple times will generate multiple passwords in wnt.env 

Updating older instances might cause issues in databases. Please update instances periodically. E.g 2.0 -> 3.0 -> 4.0