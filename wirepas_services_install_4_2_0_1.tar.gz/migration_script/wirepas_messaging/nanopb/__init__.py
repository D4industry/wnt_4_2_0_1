"""
    Wirepas Messaging
    =================

"""
# flake8: noqa

from .nanopb_pb2 import *
